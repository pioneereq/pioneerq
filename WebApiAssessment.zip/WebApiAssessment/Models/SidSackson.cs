﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;


namespace WebApiAssessment.Models
{
    public class Point
    {
        public int X
        {
            get;
            set;
        }
        public int Y
        {
            get;
            set;
        }
    }

    public class Line
    {
        public int Start
        {
            get;
            set;
        }
        public int End
        {
            get;
            set;
        }
    }

    public class State_Update
    {
        public Line newline { get; set; }
        public string heading { get; set; }
        public string message { get; set; }
    }

    public class PayLoad
    {
         public string msg { get; set; }

        /// <summary>
        /// State_Update | Point | String
        /// </summary>
        public Object body { get; set; }
        
    }
}