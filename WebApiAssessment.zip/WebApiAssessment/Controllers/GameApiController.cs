﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApiAssessment.Models;

/// <summary>
/// http://localhost:63236//api/GameApi/Get
/// </summary>
namespace WebApiAssessment.Controllers
{
    public class GameApiController : ApiController
    {
        /// <summary>
        /// Default: 4 as matrix dimension
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public PayLoad Get()
        {
            return Get(4);
        }

        /// <summary>
        /// Read
        /// http://localhost:63236/api/GameApi/Get
        /// </summary>
        /// <retu
        /// rns></returns>
        /// 
        [HttpGet]
        public PayLoad Get(int dimlevel)
        {
            PayLoad payLoad = new PayLoad();
            try
            {
                int[] padding = new int[] { 140, 130, 120, 110, 100, 90, 80, 70, 60, 50 };
                int alignment = padding[dimlevel];
                IList<Point> points = new List<Point>();

                payLoad.msg = string.Empty;
                payLoad.body = string.Empty;

                for (int rowCount = 0; rowCount < dimlevel; rowCount++)
                {
                    for (int colCount = 0; colCount < dimlevel; colCount++)
                    {
                        points.Add(new Point() { X = rowCount + (alignment * rowCount), Y = colCount + (alignment * colCount) });
                    }
                }
                payLoad.body = points;
            }
            catch (Exception e)
            {
                payLoad.msg = e.StackTrace;
                payLoad.body = HttpStatusCode.ExpectationFailed;
            }
            return payLoad;
        }


        /// <summary>
        /// POST api/Post
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>        
        [HttpPost]
        public string Post([FromBody]string value)
        {
            return "Hello World";
        }

        /// <summary>
        /// Put api/Put/9
        /// </summary>
        /// <param name="id"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        [HttpPut]
        public string Put(int id, [FromBody]string value)
        {
            return "Hello World";
        }

        /// <summary>
        /// Clean up 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        public string Delete(int id)
        {
            return "Hello World";
        }
    }
}
