﻿using System.Web.Mvc;

/// <summary>
/// http://localhost:58260/Home
/// </summary>

namespace WebApiAssessment.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Side Sackson Game.";

            return View();
        }

        public ActionResult ReadME()
        {
            ViewBag.Message = "Main menu including Game, About and Readme";

            return View();
        }
    }
}